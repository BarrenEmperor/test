#ifndef SRC_SERIALPORT_UNIX_H_
#define SRC_SERIALPORT_UNIX_H_

int ToBaudConstant(int baudRate);
int ToDataBitsConstant(int dataBits);

#endif  // SRC_SERIALPORT_UNIX_H_
